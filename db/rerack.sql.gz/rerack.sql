# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: us-cdbr-east-04.cleardb.com (MySQL 5.5.31-log)
# Database: heroku_59868427eb8ef14
# Generation Time: 2013-08-30 01:22:46 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table houses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `houses`;

CREATE TABLE `houses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `rules` text NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(32) NOT NULL,
  `left` tinyint(4) NOT NULL,
  `played` tinyint(4) NOT NULL,
  `tt_name` varchar(32) NOT NULL,
  `tt_wins` int(4) NOT NULL,
  `tables` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `top_team_id` (`tt_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `houses` WRITE;
/*!40000 ALTER TABLE `houses` DISABLE KEYS */;

INSERT INTO `houses` (`id`, `user_id`, `rules`, `code`, `name`, `left`, `played`, `tt_name`, `tt_wins`, `tables`)
VALUES
	(1,1,'Lance Rack<br />\r\nUnlimited Island<br />\r\nStraight Recovery<br />\r\nBounce is Two<br />\r\nNo Leaning','smyod','2111 Burdett',5,1,'Highland Kids',1,1);

/*!40000 ALTER TABLE `houses` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tables
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tables`;

CREATE TABLE `tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `house_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `opponent_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `house_id` (`house_id`,`team_id`,`opponent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `tables` WRITE;
/*!40000 ALTER TABLE `tables` DISABLE KEYS */;

INSERT INTO `tables` (`id`, `house_id`, `team_id`, `opponent_id`)
VALUES
	(1,1,2,4);

/*!40000 ALTER TABLE `tables` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table teams
# ------------------------------------------------------------

DROP TABLE IF EXISTS `teams`;

CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `number` int(10) NOT NULL,
  `player` varchar(16) NOT NULL,
  `teammate` varchar(16) NOT NULL,
  `wins` int(11) NOT NULL,
  `queued` tinyint(1) NOT NULL DEFAULT '1',
  `house_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `house_id` (`house_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;

INSERT INTO `teams` (`id`, `name`, `number`, `player`, `teammate`, `wins`, `queued`, `house_id`)
VALUES
	(7,'Double Bounce',1234567890,'Jeff','John',0,1,1),
	(2,'Highland Kids',1234567890,'missy','nicole',1,0,1),
	(6,'Team Thunder',2036682177,'chris','justin',0,1,1),
	(4,'Starko',2147483647,'Steve','Marko',0,0,1),
	(8,'team name',1234567890,'one ','two',0,1,1),
	(9,'hedgeye',2147483647,'your first name','teammate name',0,1,1),
	(11,'Testes',2147483647,'Steve','Chris',0,1,1);

/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `house_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `number` varchar(10) NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
